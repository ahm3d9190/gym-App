from fastapi.testclient import TestClient
from api.index import app

client = TestClient(app)

def test_read_root():
    response = client.get("/api")
    assert response.status_code == 200
    assert response.json() == {"message": "Welcome to the Calorie Counter AI API!"}

def test_analyze_image():
    response = client.get("/api/analyze")
    assert response.status_code == 200
    assert response.json() == {
        "food": "Pizza",
        "calories": 270,
        "protein": 11,
        "fat": 10,
        "carbs": 30
    }
