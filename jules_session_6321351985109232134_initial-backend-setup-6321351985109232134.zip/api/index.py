from fastapi import FastAPI

app = FastAPI()

@app.get("/api")
def read_root():
    return {"message": "Welcome to the Calorie Counter AI API!"}

@app.get("/api/analyze")
def analyze_image():
    # This is a mock response.
    # In the future, this will process an image and return real data.
    return {
        "food": "Pizza",
        "calories": 270,
        "protein": 11,
        "fat": 10,
        "carbs": 30
    }
